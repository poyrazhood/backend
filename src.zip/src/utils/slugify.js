import slugify from 'slugify';

/**
 * Türkçe karakterleri İngilizce karşılıklarına çevirir ve SEO-friendly slug oluşturur
 * @param {string} text - Slug'a çevrilecek metin
 * @returns {string} - URL-friendly slug
 * 
 * Örnek: "Çiçek Kebap & Salonu" -> "cicek-kebap-salonu"
 */
export function generateSlug(text) {
  if (!text) return '';

  // Türkçe karakterleri İngilizce karşılıklarına çevir
  const turkishMap = {
    'ğ': 'g', 'Ğ': 'G',
    'ü': 'u', 'Ü': 'U',
    'ş': 's', 'Ş': 'S',
    'ı': 'i', 'İ': 'I',
    'ö': 'o', 'Ö': 'O',
    'ç': 'c', 'Ç': 'C'
  };

  let converted = text;
  Object.keys(turkishMap).forEach(key => {
    converted = converted.replace(new RegExp(key, 'g'), turkishMap[key]);
  });

  // Slugify ile URL-friendly hale getir
  return slugify(converted, {
    lower: true,           // Küçük harfe çevir
    strict: true,          // Özel karakterleri kaldır
    remove: /[*+~.()'"!:@]/g, // Ekstra özel karakterleri kaldır
  });
}

/**
 * Slug collision durumunda benzersiz slug oluşturur
 * @param {string} baseSlug - Temel slug
 * @param {Function} checkExists - Slug'ın var olup olmadığını kontrol eden async fonksiyon
 * @returns {Promise<string>} - Benzersiz slug
 * 
 * Örnek: "mekan" varsa -> "mekan-1", "mekan-1" varsa -> "mekan-2"
 */
export async function generateUniqueSlug(baseSlug, checkExists) {
  let slug = baseSlug;
  let counter = 1;

  // Slug var olduğu sürece sayaç ekle
  while (await checkExists(slug)) {
    slug = `${baseSlug}-${counter}`;
    counter++;
  }

  return slug;
}
