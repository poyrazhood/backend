/**
 * Tecrubelerim.com - Main Application Entry Point
 * High-Scale Local Business Discovery Platform
 */

import Fastify from 'fastify';
import { PrismaClient } from '@prisma/client';
import { createClient } from 'redis';
import { authenticate } from './middleware/auth.js';
import authRoutes from './routes/authRoutes.js';
import businessRoutes from './routes/businessRoutes.js';
import reviewRoutes from './routes/reviewRoutes.js';

// Initialize Prisma Client
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

// Initialize Redis Client
const redis = createClient({
  url: process.env.REDIS_URL,
});

redis.on('error', (err) => console.error('Redis Client Error:', err));
redis.on('connect', () => console.log('✓ Redis connected'));

// Initialize Fastify
const fastify = Fastify({
  logger: {
    level: process.env.NODE_ENV === 'development' ? 'info' : 'warn',
  },
});

// Decorate fastify with authenticate middleware
fastify.decorate('authenticate', authenticate);

// Register routes
fastify.register(authRoutes, { prefix: '/auth' });
fastify.register(businessRoutes, { prefix: '/businesses' });
fastify.register(reviewRoutes, { prefix: '/reviews' });

// Health Check Endpoint
fastify.get('/health', async (request, reply) => {
  try {
    // Check database connection
    await prisma.$queryRaw`SELECT 1`;
    
    // Check Redis connection
    await redis.ping();
    
    return {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        redis: 'connected',
      },
    };
  } catch (error) {
    reply.code(503);
    return {
      status: 'unhealthy',
      error: error.message,
    };
  }
});

// Root Endpoint
fastify.get('/', async (request, reply) => {
  return {
    name: 'Tecrubelerim.com API',
    version: '0.1.0',
    status: 'operational',
    message: 'High-trust local business discovery platform',
    endpoints: {
      health: '/health',
      docs: '/docs (coming soon)',
    },
  };
});

// Graceful Shutdown
const gracefulShutdown = async () => {
  console.log('\n🛑 Shutting down gracefully...');
  
  try {
    await fastify.close();
    await prisma.$disconnect();
    await redis.quit();
    console.log('✓ All connections closed');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start Server
const start = async () => {
  try {
    // Connect to Redis
    await redis.connect();
    
    // Test database connection
    await prisma.$connect();
    console.log('✓ Database connected');
    
    // Start Fastify server
    const port = process.env.PORT || 3000;
    await fastify.listen({ port, host: '0.0.0.0' });
    
    console.log(`\n🚀 Tecrubelerim.com API running on port ${port}`);
    console.log(`📊 Environment: ${process.env.NODE_ENV}`);
    console.log(`🔗 Health check: http://localhost:${port}/health\n`);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

start();
