import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * Kullanıcının güven skorunu günceller
 * @param {string} userId - Kullanıcı ID
 * @param {string} action - Aksiyon tipi: 'review_published', 'helpful_vote', 'verified'
 * @param {object} metadata - Ek bilgiler (opsiyonel)
 * @returns {Promise<object>} - Güncellenmiş kullanıcı ve skor geçmişi
 */
export async function updateTrustScore(userId, action, metadata = {}) {
  // Mevcut kullanıcıyı al
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      trustScore: true,
      totalReviews: true,
      helpfulVotes: true,
      verifiedReviews: true,
    },
  });

  if (!user) {
    throw new Error('User not found');
  }

  const oldScore = user.trustScore;
  let scoreChange = 0;
  let reason = '';

  // Aksiyona göre puan değişimi
  switch (action) {
    case 'review_published':
      scoreChange = 5;
      reason = 'Review published';
      break;
    
    case 'helpful_vote':
      scoreChange = 2;
      reason = 'Received helpful vote';
      break;
    
    case 'verified':
      scoreChange = 10;
      reason = 'Account verified';
      break;
    
    case 'review_removed':
      scoreChange = -3;
      reason = 'Review removed for policy violation';
      break;
    
    case 'spam_detected':
      scoreChange = -10;
      reason = 'Spam or fake review detected';
      break;
    
    default:
      throw new Error(`Unknown action: ${action}`);
  }

  // Yeni skoru hesapla (0-100 arasında tut)
  const newScore = Math.max(0, Math.min(100, oldScore + scoreChange));

  // Trust level'ı hesapla
  const trustLevel = calculateTrustLevel(newScore);

  // Kullanıcıyı güncelle
  const updatedUser = await prisma.user.update({
    where: { id: userId },
    data: {
      trustScore: newScore,
      trustLevel,
    },
  });

  // Trust score geçmişine kaydet
  await prisma.trustScoreHistory.create({
    data: {
      userId,
      oldScore,
      newScore,
      reason,
      metadata,
    },
  });

  return {
    user: updatedUser,
    scoreChange,
    oldScore,
    newScore,
  };
}

/**
 * Trust score'a göre trust level hesaplar
 * @param {number} score - Trust score (0-100)
 * @returns {string} - Trust level
 */
function calculateTrustLevel(score) {
  if (score >= 86) return 'VERIFIED';
  if (score >= 71) return 'HIGHLY_TRUSTED';
  if (score >= 51) return 'TRUSTED';
  if (score >= 31) return 'DEVELOPING';
  return 'NEWCOMER';
}

/**
 * Kullanıcının rozet seviyesini hesaplar ve günceller
 * @param {string} userId - Kullanıcı ID
 * @returns {Promise<object>} - Güncellenmiş kullanıcı ve rozet bilgisi
 */
export async function calculateBadgeLevel(userId) {
  // Kullanıcı verilerini al
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      totalReviews: true,
      helpfulVotes: true,
      verifiedReviews: true,
      badgeLevel: true,
      emailVerified: true,
      phoneVerified: true,
    },
  });

  if (!user) {
    throw new Error('User not found');
  }

  // Yararlı oy yüzdesini hesapla
  const helpfulPercentage = user.totalReviews > 0 
    ? (user.helpfulVotes / user.totalReviews) * 100 
    : 0;

  // Doğrulama durumu (email veya telefon doğrulanmış mı?)
  const isVerified = user.emailVerified || user.phoneVerified;

  let newBadgeLevel = 'NONE';

  // Rozet seviyesini hesapla
  if (user.totalReviews >= 500) {
    // PLATINUM: 500+ yorum (moderatör statüsü için aday)
    newBadgeLevel = 'PLATINUM';
  } else if (
    user.totalReviews >= 50 && 
    helpfulPercentage >= 90 && 
    isVerified
  ) {
    // GOLD: 50+ yorum, %90+ yararlı, doğrulanmış
    newBadgeLevel = 'GOLD';
  } else if (
    user.totalReviews >= 20 && 
    helpfulPercentage >= 80
  ) {
    // SILVER: 20+ yorum, %80+ yararlı
    newBadgeLevel = 'SILVER';
  } else if (user.totalReviews >= 5) {
    // BRONZE: 5+ yorum
    newBadgeLevel = 'BRONZE';
  }

  // Rozet seviyesi değiştiyse güncelle
  if (newBadgeLevel !== user.badgeLevel) {
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: { badgeLevel: newBadgeLevel },
    });

    return {
      user: updatedUser,
      badgeChanged: true,
      oldBadge: user.badgeLevel,
      newBadge: newBadgeLevel,
      stats: {
        totalReviews: user.totalReviews,
        helpfulVotes: user.helpfulVotes,
        helpfulPercentage: helpfulPercentage.toFixed(2),
        isVerified,
      },
    };
  }

  return {
    user,
    badgeChanged: false,
    currentBadge: user.badgeLevel,
    stats: {
      totalReviews: user.totalReviews,
      helpfulVotes: user.helpfulVotes,
      helpfulPercentage: helpfulPercentage.toFixed(2),
      isVerified,
    },
  };
}

/**
 * Kullanıcının tam profil bilgilerini döner (trust score + badge dahil)
 * @param {string} userId - Kullanıcı ID
 * @returns {Promise<object>} - Kullanıcı profili
 */
export async function getUserProfile(userId) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      username: true,
      email: true,
      fullName: true,
      avatarUrl: true,
      trustScore: true,
      trustLevel: true,
      badgeLevel: true,
      totalReviews: true,
      helpfulVotes: true,
      verifiedReviews: true,
      emailVerified: true,
      phoneVerified: true,
      profileViews: true,
      followersCount: true,
      followingCount: true,
      createdAt: true,
    },
  });

  if (!user) {
    throw new Error('User not found');
  }

  // Yararlı oy yüzdesini hesapla
  const helpfulPercentage = user.totalReviews > 0 
    ? ((user.helpfulVotes / user.totalReviews) * 100).toFixed(2)
    : 0;

  return {
    ...user,
    stats: {
      helpfulPercentage,
      isVerified: user.emailVerified || user.phoneVerified,
    },
  };
}
