import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { getUserProfile } from '../services/userService.js';

const prisma = new PrismaClient();

async function authRoutes(fastify, options) {

  // User Registration
  fastify.post('/register', async (request, reply) => {
    const { email, username, password } = request.body;

    if (!email || !username || !password) {
      return reply.code(400).send({ message: 'Email, username, and password are required' });
    }

    try {
      // Check if user already exists
      const existingUser = await prisma.user.findFirst({
        where: {
          OR: [
            { email: email.toLowerCase() },
            { username: username.toLowerCase() }
          ],
        },
      });

      if (existingUser) {
        return reply.code(409).send({ message: 'User with this email or username already exists' });
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, 10);

      // Create user
      const user = await prisma.user.create({
        data: {
          email: email.toLowerCase(),
          username: username.toLowerCase(),
          passwordHash,
          // Default values for trustScore, badgeLevel, etc., are handled by Prisma schema
        },
      });

      // Generate JWT Token
      const token = jwt.sign({ userId: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });

      return reply.code(201).send({ message: 'User registered successfully', user: { id: user.id, username: user.username, email: user.email }, token });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during registration' });
    }
  });

  // User Login
  fastify.post('/login', async (request, reply) => {
    const { identifier, password } = request.body; // 'identifier' can be email or username

    if (!identifier || !password) {
      return reply.code(400).send({ message: 'Identifier (email/username) and password are required' });
    }

    try {
      // Find user by email or username
      const user = await prisma.user.findFirst({
        where: {
          OR: [
            { email: identifier.toLowerCase() },
            { username: identifier.toLowerCase() }
          ],
        },
      });

      if (!user) {
        return reply.code(401).send({ message: 'Invalid credentials' });
      }

      // Compare password
      const isPasswordValid = await bcrypt.compare(password, user.passwordHash);

      if (!isPasswordValid) {
        return reply.code(401).send({ message: 'Invalid credentials' });
      }

      // Update lastLoginAt
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      // Generate JWT Token
      const token = jwt.sign({ userId: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });

      return reply.code(200).send({ message: 'Logged in successfully', user: { id: user.id, username: user.username, email: user.email }, token });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during login' });
    }
  });

  // Get Current User Profile (Protected)
  fastify.get('/me', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    try {
      const userProfile = await getUserProfile(request.user.userId);
      
      return reply.code(200).send({
        message: 'User profile retrieved successfully',
        user: userProfile
      });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error while fetching user profile' });
    }
  });
}

export default authRoutes;
