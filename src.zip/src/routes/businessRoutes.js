import { PrismaClient } from '@prisma/client';
import { generateSlug, generateUniqueSlug } from '../utils/slugify.js';

const prisma = new PrismaClient();

async function businessRoutes(fastify, options) {

  // Create Business (Protected - requires authentication)
  fastify.post('/', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { name, address, city, district, categoryId, description, phoneNumber, email, website, attributes } = request.body;

    if (!name || !address || !city || !categoryId) {
      return reply.code(400).send({ message: 'Name, address, city, and categoryId are required' });
    }

    try {
      // Türkçe karakterleri dönüştürerek slug oluştur
      const baseSlug = generateSlug(name);

      // Slug collision kontrolü ve benzersiz slug oluştur
      const checkSlugExists = async (slug) => {
        const existing = await prisma.business.findUnique({
          where: { slug },
        });
        return !!existing;
      };

      const slug = await generateUniqueSlug(baseSlug, checkSlugExists);

      // Create business
      const business = await prisma.business.create({
        data: {
          name,
          slug,
          address,
          city,
          district,
          categoryId,
          description,
          phoneNumber,
          email,
          website,
          attributes: attributes || {},
          ownerId: request.user.userId, // Set the authenticated user as owner
        },
        include: {
          category: true,
        },
      });

      return reply.code(201).send({ message: 'Business created successfully', business });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during business creation' });
    }
  });

  // Get All Businesses (Public - with pagination and filtering)
  fastify.get('/', async (request, reply) => {
    const { page = 1, limit = 20, city, categoryId, search } = request.query;

    const skip = (page - 1) * limit;

    try {
      const where = {
        isActive: true,
        isDeleted: false,
      };

      if (city) {
        where.city = city;
      }

      if (categoryId) {
        where.categoryId = categoryId;
      }

      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [businesses, total] = await Promise.all([
        prisma.business.findMany({
          where,
          skip: parseInt(skip),
          take: parseInt(limit),
          include: {
            category: true,
            owner: {
              select: {
                id: true,
                username: true,
                badgeLevel: true,
              },
            },
          },
          orderBy: {
            averageRating: 'desc',
          },
        }),
        prisma.business.count({ where }),
      ]);

      return reply.code(200).send({
        businesses,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error while fetching businesses' });
    }
  });

  // Get Business by Slug (Public)
  fastify.get('/:slug', async (request, reply) => {
    const { slug } = request.params;

    try {
      const business = await prisma.business.findUnique({
        where: { slug },
        include: {
          category: true,
          owner: {
            select: {
              id: true,
              username: true,
              badgeLevel: true,
              trustScore: true,
            },
          },
          reviews: {
            where: {
              isPublished: true,
            },
            include: {
              user: {
                select: {
                  id: true,
                  username: true,
                  badgeLevel: true,
                  trustScore: true,
                },
              },
            },
            orderBy: {
              createdAt: 'desc',
            },
            take: 10, // Limit to 10 most recent reviews
          },
        },
      });

      if (!business || business.isDeleted) {
        return reply.code(404).send({ message: 'Business not found' });
      }

      // Increment view count
      await prisma.business.update({
        where: { id: business.id },
        data: { totalViews: { increment: 1 } },
      });

      return reply.code(200).send({ business });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error while fetching business' });
    }
  });

  // Update Business (Protected - only owner can update)
  fastify.put('/:slug', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { slug } = request.params;
    const { name, address, city, district, description, phoneNumber, email, website, attributes } = request.body;

    try {
      const business = await prisma.business.findUnique({
        where: { slug },
      });

      if (!business) {
        return reply.code(404).send({ message: 'Business not found' });
      }

      // Check if the authenticated user is the owner
      if (business.ownerId !== request.user.userId) {
        return reply.code(403).send({ message: 'You are not authorized to update this business' });
      }

      const updatedBusiness = await prisma.business.update({
        where: { slug },
        data: {
          name,
          address,
          city,
          district,
          description,
          phoneNumber,
          email,
          website,
          attributes: attributes || business.attributes,
        },
        include: {
          category: true,
        },
      });

      return reply.code(200).send({ message: 'Business updated successfully', business: updatedBusiness });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during business update' });
    }
  });

  // Delete Business (Protected - only owner can delete)
  fastify.delete('/:slug', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { slug } = request.params;

    try {
      const business = await prisma.business.findUnique({
        where: { slug },
      });

      if (!business) {
        return reply.code(404).send({ message: 'Business not found' });
      }

      // Check if the authenticated user is the owner
      if (business.ownerId !== request.user.userId) {
        return reply.code(403).send({ message: 'You are not authorized to delete this business' });
      }

      // Soft delete
      await prisma.business.update({
        where: { slug },
        data: {
          isDeleted: true,
          isActive: false,
        },
      });

      return reply.code(200).send({ message: 'Business deleted successfully' });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during business deletion' });
    }
  });
}

export default businessRoutes;
