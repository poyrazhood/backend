import { PrismaClient } from '@prisma/client';
import { updateTrustScore, calculateBadgeLevel } from '../services/userService.js';

const prisma = new PrismaClient();

// Basic fraud detection helper
function detectFraudPatterns(content, rating, userTrustScore) {
  const fraudScore = 0;
  const riskFactors = [];

  // Pattern 1: Very short reviews with extreme ratings
  if (content.length < 20 && (rating === 1 || rating === 5)) {
    fraudScore += 20;
    riskFactors.push('short_extreme_rating');
  }

  // Pattern 2: All caps (shouting)
  if (content === content.toUpperCase() && content.length > 10) {
    fraudScore += 15;
    riskFactors.push('all_caps');
  }

  // Pattern 3: Excessive punctuation
  const punctuationCount = (content.match(/[!?]{2,}/g) || []).length;
  if (punctuationCount > 3) {
    fraudScore += 10;
    riskFactors.push('excessive_punctuation');
  }

  // Pattern 4: Low trust score user
  if (userTrustScore < 30) {
    fraudScore += 25;
    riskFactors.push('low_trust_user');
  }

  // Pattern 5: Generic template phrases
  const genericPhrases = ['best ever', 'worst ever', 'highly recommend', 'never go back'];
  const hasGeneric = genericPhrases.some(phrase => content.toLowerCase().includes(phrase));
  if (hasGeneric && content.length < 50) {
    fraudScore += 15;
    riskFactors.push('generic_template');
  }

  return {
    fraud_score: Math.min(fraudScore, 100),
    detection_method: 'rule_based',
    risk_factors: riskFactors,
    automated_action: fraudScore > 60 ? 'quarantine' : fraudScore > 30 ? 'flag' : 'publish',
  };
}

async function reviewRoutes(fastify, options) {

  // Create Review (Protected - requires authentication)
  fastify.post('/', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { businessId, rating, title, content } = request.body;

    if (!businessId || !rating || !content) {
      return reply.code(400).send({ message: 'BusinessId, rating, and content are required' });
    }

    if (rating < 1 || rating > 5) {
      return reply.code(400).send({ message: 'Rating must be between 1 and 5' });
    }

    try {
      // Check if business exists
      const business = await prisma.business.findUnique({
        where: { id: businessId },
      });

      if (!business || business.isDeleted) {
        return reply.code(404).send({ message: 'Business not found' });
      }

      // Check if user already reviewed this business
      const existingReview = await prisma.review.findUnique({
        where: {
          userId_businessId: {
            userId: request.user.userId,
            businessId,
          },
        },
      });

      if (existingReview) {
        return reply.code(409).send({ message: 'You have already reviewed this business' });
      }

      // Get user trust score for fraud detection
      const user = await prisma.user.findUnique({
        where: { id: request.user.userId },
        select: { trustScore: true },
      });

      // Run fraud detection
      const fraudMetadata = detectFraudPatterns(content, rating, user.trustScore);

      // Determine if review should be published immediately
      const isPublished = fraudMetadata.automated_action !== 'quarantine';
      const isFlagged = fraudMetadata.automated_action === 'flag' || fraudMetadata.automated_action === 'quarantine';

      // Create review
      const review = await prisma.review.create({
        data: {
          userId: request.user.userId,
          businessId,
          rating,
          title,
          content,
          isPublished,
          isFlagged,
          fraudDetectionMetadata: fraudMetadata,
        },
        include: {
          user: {
            select: {
              id: true,
              username: true,
              badgeLevel: true,
              trustScore: true,
            },
          },
          business: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      });

      // Yorum yayınlandıysa trust score ve badge güncelle
      if (isPublished) {
        try {
          await updateTrustScore(request.user.userId, 'review_published', {
            reviewId: review.id,
            businessId,
          });
          await calculateBadgeLevel(request.user.userId);
        } catch (error) {
          fastify.log.error('Trust score update failed:', error);
          // Hata olsa bile yorum oluşturuldu, devam et
        }
      }

      // Update business average rating and total reviews
      const reviews = await prisma.review.findMany({
        where: {
          businessId,
          isPublished: true,
        },
        select: {
          rating: true,
        },
      });

      const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;

      await prisma.business.update({
        where: { id: businessId },
        data: {
          averageRating,
          totalReviews: reviews.length,
        },
      });

      const message = isPublished
        ? 'Review created successfully'
        : 'Review submitted for moderation (flagged by fraud detection)';

      return reply.code(201).send({ message, review, fraudDetection: fraudMetadata });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during review creation' });
    }
  });

  // Get Reviews for a Business (Public)
  fastify.get('/business/:businessId', async (request, reply) => {
    const { businessId } = request.params;
    const { page = 1, limit = 20, rating } = request.query;

    const skip = (page - 1) * limit;

    try {
      const where = {
        businessId,
        isPublished: true,
      };

      if (rating) {
        where.rating = parseInt(rating);
      }

      const [reviews, total] = await Promise.all([
        prisma.review.findMany({
          where,
          skip: parseInt(skip),
          take: parseInt(limit),
          include: {
            user: {
              select: {
                id: true,
                username: true,
                badgeLevel: true,
                trustScore: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        }),
        prisma.review.count({ where }),
      ]);

      return reply.code(200).send({
        reviews,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error while fetching reviews' });
    }
  });

  // Get User's Reviews (Protected)
  fastify.get('/my-reviews', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { page = 1, limit = 20 } = request.query;

    const skip = (page - 1) * limit;

    try {
      const [reviews, total] = await Promise.all([
        prisma.review.findMany({
          where: {
            userId: request.user.userId,
          },
          skip: parseInt(skip),
          take: parseInt(limit),
          include: {
            business: {
              select: {
                id: true,
                name: true,
                slug: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        }),
        prisma.review.count({
          where: {
            userId: request.user.userId,
          },
        }),
      ]);

      return reply.code(200).send({
        reviews,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error while fetching user reviews' });
    }
  });

  // Update Review (Protected - only review author can update)
  fastify.put('/:reviewId', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { reviewId } = request.params;
    const { rating, title, content } = request.body;

    try {
      const review = await prisma.review.findUnique({
        where: { id: reviewId },
      });

      if (!review) {
        return reply.code(404).send({ message: 'Review not found' });
      }

      // Check if the authenticated user is the author
      if (review.userId !== request.user.userId) {
        return reply.code(403).send({ message: 'You are not authorized to update this review' });
      }

      // Get user trust score for fraud detection
      const user = await prisma.user.findUnique({
        where: { id: request.user.userId },
        select: { trustScore: true },
      });

      // Run fraud detection on updated content
      const fraudMetadata = detectFraudPatterns(content || review.content, rating || review.rating, user.trustScore);

      const isPublished = fraudMetadata.automated_action !== 'quarantine';
      const isFlagged = fraudMetadata.automated_action === 'flag' || fraudMetadata.automated_action === 'quarantine';

      const updatedReview = await prisma.review.update({
        where: { id: reviewId },
        data: {
          rating: rating || review.rating,
          title: title || review.title,
          content: content || review.content,
          isPublished,
          isFlagged,
          fraudDetectionMetadata: fraudMetadata,
        },
        include: {
          business: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      });

      // Recalculate business average rating
      const reviews = await prisma.review.findMany({
        where: {
          businessId: review.businessId,
          isPublished: true,
        },
        select: {
          rating: true,
        },
      });

      const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;

      await prisma.business.update({
        where: { id: review.businessId },
        data: {
          averageRating,
        },
      });

      const message = isPublished
        ? 'Review updated successfully'
        : 'Review updated and submitted for moderation (flagged by fraud detection)';

      return reply.code(200).send({ message, review: updatedReview, fraudDetection: fraudMetadata });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during review update' });
    }
  });

  // Delete Review (Protected - only review author can delete)
  fastify.delete('/:reviewId', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { reviewId } = request.params;

    try {
      const review = await prisma.review.findUnique({
        where: { id: reviewId },
      });

      if (!review) {
        return reply.code(404).send({ message: 'Review not found' });
      }

      // Check if the authenticated user is the author
      if (review.userId !== request.user.userId) {
        return reply.code(403).send({ message: 'You are not authorized to delete this review' });
      }

      await prisma.review.delete({
        where: { id: reviewId },
      });

      // Update user's total reviews count
      await prisma.user.update({
        where: { id: request.user.userId },
        data: {
          totalReviews: { decrement: 1 },
        },
      });

      // Recalculate business average rating and total reviews
      const reviews = await prisma.review.findMany({
        where: {
          businessId: review.businessId,
          isPublished: true,
        },
        select: {
          rating: true,
        },
      });

      const averageRating = reviews.length > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length : 0;

      await prisma.business.update({
        where: { id: review.businessId },
        data: {
          averageRating,
          totalReviews: reviews.length,
        },
      });

      return reply.code(200).send({ message: 'Review deleted successfully' });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error during review deletion' });
    }
  });

  // Mark Review as Helpful (Protected)
  fastify.post('/:reviewId/helpful', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { reviewId } = request.params;

    try {
      const review = await prisma.review.findUnique({
        where: { id: reviewId },
      });

      if (!review) {
        return reply.code(404).send({ message: 'Review not found' });
      }

      // Sadece yayınlanmış yorumlar için yararlı işareti kabul et
      if (!review.isPublished) {
        return reply.code(400).send({ message: 'Cannot mark unpublished review as helpful' });
      }

      // Update helpful count
      await prisma.review.update({
        where: { id: reviewId },
        data: {
          helpfulCount: { increment: 1 },
        },
      });

      // Update review author's helpful votes count
      await prisma.user.update({
        where: { id: review.userId },
        data: {
          helpfulVotes: { increment: 1 },
        },
      });

      // Yorum yazarının trust score ve badge'ini güncelle
      try {
        await updateTrustScore(review.userId, 'helpful_vote', {
          reviewId: review.id,
          votedBy: request.user.userId,
        });
        await calculateBadgeLevel(review.userId);
      } catch (error) {
        fastify.log.error('Trust score update failed:', error);
        // Hata olsa bile işlem başarılı, devam et
      }

      return reply.code(200).send({ message: 'Review marked as helpful' });

    } catch (error) {
      fastify.log.error(error);
      return reply.code(500).send({ message: 'Internal server error while marking review as helpful' });
    }
  });
}

export default reviewRoutes;
